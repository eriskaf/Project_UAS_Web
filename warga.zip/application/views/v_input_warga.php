<!DOCTYPE html>
<html lang="en">
<!--UAS 312010617-Eriska Febrianto!-->
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UAS | 312010617-Eriska Febrianto</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">

</head>

<body style="background: url('https://wallpaperaccess.com/full/4268968.jpg'); background-repeat: no-repeat; background-size: cover;">

    <div class="container col-4">
        <h2>Tambah Data Warga</h2>
        <form action="<?= base_url(); ?>Warga/tambah_aksi" method="post">
            <div class="form-group">
                <label for="exampleInputEmail1">Nomor Rumah</label>
                <input type="text" class="form-control" name="no_rumah" placeholder="Enter your no_rumah">
            </div>

            <div class="form-group">
                <label for="exampleInputPassword1">Nama</label>
                <input type="text" class="form-control" name="nama" placeholder="Enter your name">
            </div>

            <div class="form-group">
                <label for="exampleInputPassword1">Alamat</label>
                <input type="text" class="form-control" name="alamat" placeholder="Enter your Address">
            </div>

            <div class="form-group">
                <label for="exampleInputPassword1">Jumlah Keluarga</label><br>
                <input type="text" class="form-control" name="jum_kel" placeholder="Jumlah Keluarga">
            </div>

            <div class="form-group">
                <label for="exampleInputPassword1">No. HP</label>
                <input type="text" class="form-control" name="hp" placeholder="Enter your HP">
            </div>

            <div class="form-group">
                <label for="exampleInputPassword1">Bulan</label>
                <input type="text" class="form-control" name="bulan" placeholder="format yyyy-mm-dd">
            </div>
            <div class="form-group">
                <label for="exampleInputPassword1">Jumlah Iuran</label>
                <input type="text" class="form-control" name="iuran" placeholder="Enter your iuran">
            </div>
            <button type="submit" class="btn btn-primary" value="Tambah">Tambah</button>
            <button type="button" class="btn btn-primary" onclick="history.back();">Back</button>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
</body>

</html>