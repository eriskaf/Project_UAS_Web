 <!DOCTYPE htmL>
 <html>
<!--UAS 312010617-Eriska Febrianto!-->
 <head>
 	<title>UAS | 312010617-Eriska Febrianto</title>
 	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
 </head>

 <body style="background: url('https://i.pinimg.com/originals/e3/89/d2/e389d237ae990c82d9abb8c07e09fed9.jpg'); background-repeat: no-repeat; background-size: cover;">
 	<center>
 		<h1>Data Kas RT</h1><br><br>
 	</center>
 	<center>
 		<button type="submit" class="btn btn-light"><?= anchor('Warga/tambah', 'Tambah Data'); ?></button>
 	</center>

 	<table class="table">
 		<thead>
 			<tr>
 				<th scope="col">No.</th>
 				<th scope="col">No Rumah</th>
 				<th scoData Wargape="col">Nama</th>
                <th scope="col">Alamat</th>
                <th scope="col">Jumlah Keluarga</th>
 				<th scope="col">No. HP</th>
 				<th scope="col">Bulan</th>
                <th scope="col">Jumlah Iuran</th>
 				<th scope="col">Edit</th>
                <th scope="col">Hapus</th>

 			</tr>
 		</thead>
 		<tbody>
 			<?php
				$no = 1;
				foreach ($listrt as $row) {
				?>
 				<tr>
 					<td><?= $no++; ?></td>
 					<td><?= $row->no_rumah ?></td>
 					<td><?= $row->nama ?></td>
                    <td><?= $row->alamat ?></td>
                    <td><?= $row->jum_kel ?></td>
 					<td><?= $row->hp ?></td>
 					<td><?= $row->bulan ?></td>
                    <td><?= $row->iuran ?></td>
 					<td><?= anchor('Warga/edit/' . $row->no_rumah, 'Edit'); ?></td>
 					<td><?= anchor('Warga/hapus/' . $row->no_rumah, 'Hapus'); ?></td>
 				</tr>

 		</tbody>
 	<?php
				}
		?>

 	</table>

 	<center>
 		<button type="submit" class="btn btn-dark"><a href="<?= base_url() ?>auth/keluar">
 				<span>Log Out</span>
 			</a></button>
    </center>


 	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
 </body>

 </html>