<!DOCTYPE html>
<html lang="en">
<!--UAS 312010617-Eriska Febrianto!-->

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UAS | 312010617-Eriska Febrianto</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
</head>

<body>

    <div class="container col-4">
        <h2>Edit Data Warga</h2>
        <?php foreach ($listrt as $u) { ?>
            <form action="<?= base_url() . 'Warga/update' ?>" method="post">
                <div class="form-group">
                    <label for="exampleInputEmail1">no_rumah</label>
                    <input type="text" class="form-control" name="no_rumah" readonly value="<?= $u->no_rumah ?>">
                </div>

                <div class="form-group">
                    <label for="exampleInputPassword1">Nama</label>
                    <input type="text" class="form-control" name="nama" value="<?= $u->nama ?>">
                </div>

                <div class="form-group">
                    <label for="exampleInputPassword1">Alamat</label>
                    <input type="text" class="form-control" name="alamat" value="<?= $u->alamat ?>">
                </div>

                <div class="form-group">
                    <label for="exampleInputPassword1">Jumlah Keluarga</label>
                    <input type="text" class="form-control" name="jum_kel" value="<?= $u->jum_kel ?>">
                </div>

                <div class="form-group">
                    <label for="exampleInputPassword1">No. HP</label>
                    <input type="text" class="form-control" name="hp" value="<?= $u->hp ?>">
                </div>

                <div class="form-group">
                    <label for="exampleInputPassword1">Bulan</label>
                    <input type="text" class="form-control" name="bulan" value="<?= $u->bulan ?>">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Jumlah Iuran</label>
                    <input type="text" class="form-control" name="iuran" value="<?= $u->iuran ?>">
                </div>
                <button type="submit" class="btn btn-primary" value="Simpan">Simpan</button>
                <button type="button" class="btn btn-primary" onclick="history.back();">Back</button>
            </form>
        <?php } ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
</body>

</html>