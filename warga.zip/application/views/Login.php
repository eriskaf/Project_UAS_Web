<html>
<!--UAS 312010617-Eriska Febrianto!-->
    <style type="text/css">

        .card {
          background: #fbfbfb;
          border-radius: 8px;
          box-shadow: 1px 2px 8px rgba(0, 0, 0, 0.65);
          height: 410px;
          margin: 6rem auto 8.1rem auto;
          width: 329px;
          position: left;
          background: -webkit-linear-gradient(bottom, #87CEEB, #fbfbfb);
          background-repeat: no-repeat;
        }

        .msg {
          font-family: "Raleway Thin", sans-serif;
          letter-spacing: 4px;
          padding-bottom: 23px;
          padding-top: 13px;
          text-align: center;
        }

        .login-btn {
        background: -webkit-linear-gradient(right, #87CEEB, #2dbd6e);
          border: none;
          border-radius: 21px;
          box-shadow: 0px 1px 8px #24c64f;
          cursor: pointer;
          color: white;
          font-family: "Raleway SemiBold", sans-serif;
          height: 42.3px;
          margin: 0 auto;
          margin-top: 50px;
          transition: 0.25s;
          width: 153px;
        }
        .submit-btn:hover {
          box-shadow: 0px 1px 18px #87CEEB;
        }

    </style>

<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>UAS | 312010617-Eriska Febrianto</title>
    <!-- Favicon-->
    <link rel="icon" href="<?php echo base_url(); ?>adminBSB/favicon.ico" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,700&subset=latin,cyrillic-ext" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">

    <!-- Bootstrap Core Css -->
    <link href="<?php echo base_url(); ?>assets/adminBSB/plugins/bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- Waves Effect Css -->
    <link href="<?php echo base_url(); ?>assets/adminBSB/plugins/node-waves/waves.css" rel="stylesheet" />

    <!-- Animation Css -->
    <link href="<?php echo base_url(); ?>assets/adminBSB/plugins/animate-css/animate.css" rel="stylesheet" />

    <!-- Custom Css -->
    <link href="<?php echo base_url(); ?>assets/adminBSB/css/style.css" rel="stylesheet">
</head> 

<body class="login-page" style="background: url('https://lh3.googleusercontent.com/7qbFRwJYHrqAy3nkhyXfQ1ZTQoiisNMwr5p6dBo4fnq-5DoZMSfhk4hWh_xz_m7I1A_Rcp98=w1080-h608-p-no-v0'); background-repeat: no-repeat; background-size: cover;">
    <div class="login-box">
        <div class="logo">
        </div>
         <center>
        <div class="card ml-3">
            <div class="body">
                <?php if ($this->session->userdata('resetPassword')) { ?>
                    <div class="alert bg-green alert-dismissible" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                        <?=$this->session->userdata('resetPassword')?>
                    </div>
                <?php } elseif ($this->session->userdata('loginError')) { ?>
                    <div class="alert bg-green alert-dismissible" role="alert">
                        <span aria-hidden="true"></span></button>
                        <?=$this->session->userdata('loginError')?>
                    </div>
                <?php }  ?>
                <form id="sign_in" method="POST" action="<?=base_url()?>auth/login">
                    <div class="msg">LOGIN</div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <i class="material-icons">person</i>
                        </span>
                        <div class="form-line">
                            <input type="text" class="form-control" name="username" placeholder="Username" required autofocus>
                        </div>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <i class="material-icons">lock</i>
                        </span>
                        <div class="form-line">
                            <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-8 p-t-5">
                            <input type="checkbox" name="rememberme" id="rememberme" class="filled-in chk-col-pink" onclick="lihatPassword()">
                            <label for="rememberme">Lihat Password</label>
                        </div>
                        <button class="login-btn" type="submit">LOGIN</button>
                     
                    </div>
                    <div class="row m-t-15 m-b--20" align="center">
                    </div></center> 
                </form>     
            </div>
        </div>
    </div>

    <!-- Jquery Core Js -->
    <script src="<?php echo base_url(); ?>assets/adminBSB/plugins/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core Js -->
    <script src="<?php echo base_url(); ?>assets/adminBSB/plugins/bootstrap/js/bootstrap.js"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="<?php echo base_url(); ?>assets/adminBSB/plugins/node-waves/waves.js"></script>

    <!-- Validation Plugin Js -->
    <script src="<?php echo base_url(); ?>assets/adminBSB/plugins/jquery-validation/jquery.validate.js"></script>

    <!-- Custom Js -->
    <script src="<?php echo base_url(); ?>assets/adminBSB/js/admin.js"></script>
    <script src="<?php echo base_url(); ?>assets/adminBSB/js/pages/examples/sign-in.js"></script>
    <script>
        function lihatPassword()
        {
            var temp = document.getElementById("password"); 
            if (temp.type === "password") { 
              temp.type = "text"; 
            } else { 
              temp.type = "password"; 
            } 
        }
  </script>
</body>

</html>