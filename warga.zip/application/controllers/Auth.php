<?php
//UAS 312010617-Eriska Febrianto  
/**
 * 
 */
class Auth extends CI_Controller
{
	
	// function __construct()
	// {
	// 	parent::__construct();		
	// }

	public function index()
	{
		if ($this->session->userdata('status') == 'logged') {
			redirect(base_url().'Warga/index');
		} else {
			$this->load->view('Login');
		}		
	}

    public function login()
	{
		$username = $this->input->post('username');
		$password = $this->input->post('password');

		$cek_auth = $this->db->query("SELECT * FROM tb_auth WHERE username = '$username' AND password = '$password' ")->row_array();

		if (count($cek_auth) > 0) {
			$session_auth = array(
				'username' => $cek_auth['username'],
				'id' => $cek_auth['id'],
				'role' => $cek_auth['role'],
				'status' => 'logged'
			);
			$this->session->set_userdata($session_auth);
        	redirect(base_url()."Warga/index");
		} else {
			$this->session->set_flashdata('loginError', 'User atau Password yang anda masukan salah');
			redirect(base_url().'Auth');
		}
	}

	public function keluar()
	{
		$this->session->sess_destroy();
		redirect(base_url()."auth");
	}
}