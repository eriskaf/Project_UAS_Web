<?php
defined('BASEPATH') or exit('No direct script access allowed');
//UAS 312010617-Eriska Febrianto
class Warga extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('M_warga');
        $this->load->helper('url');
    }

    function index()
    {
        $data['listrt'] = $this->M_warga->get_data()->result();
        $this->load->view('vw_warga', $data);
    }

    function tambah()
    {
        $this->load->view('v_input_warga');
    }

    function tambah_aksi()
    {
        $no_rumah = $this->input->post('no_rumah');
        $nama = $this->input->post('nama');
        $alamat = $this->input->post('alamat');
        $jum_kel = $this->input->post('jum_kel');
        $hp = $this->input->post('hp');
        $bulan = $this->input->post('bulan');
        $iuran = $this->input->post('iuran');

        $data = array(
            'no_rumah' => $no_rumah,
            'nama' => $nama,
            'alamat' => $alamat,
            'jum_kel' => $jum_kel,
            'hp' => $hp,
            'bulan' => $bulan,
            'iuran' => $iuran
        );

        $this->M_warga->input_data($data, 'rt');
        redirect('warga/index');
    }

    function hapus($no_rumah)
    {
        $where = array(
            'no_rumah' => $no_rumah
        );

        $this->M_warga->hapus_data($where, 'rt');
        redirect('warga/index');
    }

    function edit($no_rumah)
    {
        $where = array(
            'no_rumah' => $no_rumah
        );
        $data['listrt'] = $this->M_warga->edit_data($where, 'rt')->result();
        $this->load->view('v_edit_warga', $data);
    }
    
    function update()
    {
        $no_rumah = $this->input->post('no_rumah');
        $nama = $this->input->post('nama');
        $alamat = $this->input->post('alamat');
        $jum_kel = $this->input->post('jum_kel');
        $hp = $this->input->post('hp');
        $bulan = $this->input->post('bulan');
        $iuran = $this->input->post('iuran');

        $data = array(
            'no_rumah' => $no_rumah,
            'nama' => $nama,
            'alamat' => $alamat,
            'jum_kel' => $jum_kel,
            'hp' => $hp,
            'bulan' => $bulan,
            'iuran' => $iuran
        );

        $where = array(
            'no_rumah' => $no_rumah
        );

        $this->M_warga->update_data($where, $data, 'rt');
        redirect('warga/index');
    }
}
